class BarangayPurok < ApplicationRecord
  belongs_to :barangay
end
