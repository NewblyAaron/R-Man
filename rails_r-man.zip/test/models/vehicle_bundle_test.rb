require "test_helper"

class VehicleBundleTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
